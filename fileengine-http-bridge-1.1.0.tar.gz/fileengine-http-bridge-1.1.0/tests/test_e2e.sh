#!/bin/bash
# End-to-end tests for the FileEngine HTTP REST bridge.
# Assumes the service is already running (default http://localhost:8090) and a
# live FileEngine gRPC core + LDAP directory are reachable.
#
# Usage: BASE=http://localhost:8090 \
#        FE_USER=<login> FE_PASS=<password> [FE_EXPECT_USER=<resolved uid>] \
#        ./tests/test_e2e.sh
# FE_USER must be a tenant ADMIN (it creates roles/ACLs). Credentials/identity are
# configurable so the suite runs against any directory.
#
# Optional (enable extra checks; otherwise those checks SKIP, not fail):
#   FE_USER2/FE_PASS2  a NON-admin member of the same tenant — proves reachability
#                      hiding applies to non-admins (admins are exempt by design).
#   FE_TENANT2         a second tenant FE_USER also belongs to — proves the
#                      X-Tenant override works for a member tenant (M3).
#   FE_CORS_ORIGIN     the bridge's configured HTTP_CORS_ORIGIN (default
#                      http://localhost:3000, the dev stack value).
#   FE_MAX_BODY        the bridge's HTTP_MAX_BODY_BYTES; the oversize-body check
#                      only runs when this is ≤ 16 MiB (else SKIP).
#
# Reflects the security-review behavior now in the bridge: `administrators` →
# tenant_admin (H2, not system_admin); X-Tenant honored only for member tenants
# (M3); 2FA challenge on login when MFA is enabled (PROPOSAL §4.6 — this suite
# needs a non-enrolled FE_USER; 2FA itself is in test_e2e_2fa.sh).

BASE="${BASE:-http://localhost:8090}"
CRED="${FE_USER:-testuser}:${FE_PASS:-password}"
WRONG="${FE_USER:-testuser}:wrongpass-nope"
EXPECT_USER="${FE_EXPECT_USER:-${FE_USER:-testuser}}"
# The primary FE_USER is a tenant administrator (member of the tenant's
# `administrators` group → `tenant_admin`). A few checks below need identities the
# admin can't provide:
#   FE_USER2/FE_PASS2  — a NON-admin member of the same tenant (roles = [users]),
#                        for the reachability-hiding check (admins are exempt).
#   FE_TENANT2         — a SECOND tenant FE_USER also belongs to, for the X-Tenant
#                        override check (M3 only lets you select a tenant you're in).
# When unset, those specific checks SKIP rather than fail.
USER2="${FE_USER2:-}"; PASS2="${FE_PASS2:-}"
TENANT2="${FE_TENANT2:-}"
# The bridge echoes its configured HTTP_CORS_ORIGIN verbatim; this must match it
# (dev stack default is http://localhost:3000).
CORS_ORIGIN="${FE_CORS_ORIGIN:-http://localhost:3000}"
# The bridge's request-body cap (HTTP_MAX_BODY_BYTES). The oversize check only runs
# when this is small enough to exercise cheaply; otherwise it SKIPs (see below).
MAX_BODY="${FE_MAX_BODY:-104857600}"
PASS=0; FAIL=0; SKIP=0; FAILED=()
ok()   { PASS=$((PASS+1)); printf '  \033[32m✓\033[0m %s\n' "$1"; }
bad()  { FAIL=$((FAIL+1)); FAILED+=("$1"); printf '  \033[31m✗\033[0m %s\n     %s\n' "$1" "${2:-}"; }
skip() { SKIP=$((SKIP+1)); printf '  \033[33m⊘ SKIP\033[0m %s\n' "$1"; }

echo "=========================================================="
echo " FileEngine HTTP bridge — E2E   base=$BASE"
echo "=========================================================="

# ---- health ----
echo "[health]"
body=$(curl -s -o /tmp/hb_body -w '%{http_code}' "$BASE/healthz"); code=$body
[ "$code" = "200" ] && ok "GET /healthz -> 200" || bad "GET /healthz -> 200" "got $code"
if grep -q '"status"' /tmp/hb_body && grep -q 'ok' /tmp/hb_body; then ok "healthz body {status: ok}"; else bad "healthz body" "$(cat /tmp/hb_body)"; fi

# ---- auth + tenant (whoami) ----
echo "[auth]"
code=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/v1/whoami")
[ "$code" = "401" ] && ok "whoami without creds -> 401" || bad "whoami without creds -> 401" "got $code"

out=$(curl -s -u "$CRED" "$BASE/v1/whoami")
grep -q "\"user\":\"$EXPECT_USER\"" <<<"$out" && ok "whoami authenticates testuser (LDAP)" || bad "whoami testuser" "$out"
grep -q '"tenant":"default"' <<<"$out" && ok "default tenant (non-subdomain)" || bad "default tenant" "$out"
# H2: a tenant's `administrators` group aliases to the tenant-scoped `tenant_admin`
# role (NOT the global `system_admin`, which must be granted explicitly). This is
# what keeps a tenant admin from crossing tenant boundaries.
grep -q 'tenant_admin' <<<"$out" && ok "administrators group -> tenant_admin role (H2)" || bad "tenant_admin role" "$out"
grep -q 'system_admin' <<<"$out" && bad "tenant admin must NOT be global system_admin (H2)" "$out" \
    || ok "tenant admin is not global system_admin (H2)"

code=$(curl -s -o /dev/null -w '%{http_code}' -u "$WRONG" "$BASE/v1/whoami")
[ "$code" = "401" ] && ok "wrong password -> 401" || bad "wrong password -> 401" "got $code"

# X-Tenant selects the active tenant — but M3 only honors it for a tenant the user
# is actually a member of. Positive case (a second member tenant):
if [ -n "$TENANT2" ]; then
    out=$(curl -s -u "$CRED" -H "X-Tenant: $TENANT2" "$BASE/v1/whoami")
    grep -q "\"tenant\":\"$TENANT2\"" <<<"$out" && ok "X-Tenant overrides to a member tenant ($TENANT2)" || bad "X-Tenant override" "$out"
else
    skip "X-Tenant override to a member tenant (set FE_TENANT2 to a second tenant FE_USER belongs to)"
fi
# Negative case (M3): selecting a tenant the user is NOT a member of is refused,
# never silently honored. A bogus tenant name is a guaranteed non-membership.
code=$(curl -s -o /dev/null -w '%{http_code}' -u "$CRED" -H 'X-Tenant: no-such-tenant-zzz' "$BASE/v1/whoami")
[ "$code" = "403" ] && ok "X-Tenant to a non-member tenant -> 403 (M3)" || bad "M3 X-Tenant enforcement" "got $code"

# ---- token auth ----
echo "[token auth]"
out=$(curl -s -u "$CRED" -X POST "$BASE/v1/auth/token")
# New feature (2FA, PROPOSAL §4.6): when the bridge runs with MFA_ENABLED and
# FE_USER has 2FA enrolled, /v1/auth/token returns {mfa_required, mfa_token}
# instead of a session — this suite drives the password path, so it needs a
# NON-enrolled FE_USER. Detect + bail out clearly rather than cascading failures.
if grep -q '"mfa_required":true' <<<"$out"; then
    echo "  \033[33m⊘\033[0m FE_USER has 2FA enrolled; this suite needs a non-enrolled user (or MFA off)."
    echo "     (2FA itself is covered by tests/test_e2e_2fa.sh.)"
    echo " ABORTING token-dependent checks."
    exit 0
fi
# The bearer token is a signed HS256 JWT (base64url segments, dot-separated).
TOKEN=$(grep -oE '"token":"[^"]+"' <<<"$out" | sed 's/.*"token":"//;s/"//')
[ -n "$TOKEN" ] && ok "POST /v1/auth/token issues token" || bad "issue token" "$out"
grep -q '"token_type":"Bearer"' <<<"$out" && ok "token_type Bearer + expires_in" || bad "token_type" "$out"
# Shape: a JWT is three dot-separated segments; the roles claim is a {tenant:[..]} map.
[ "$(awk -F. '{print NF}' <<<"$TOKEN")" = "3" ] && ok "token is a 3-part JWT" || bad "jwt shape" "$TOKEN"
grep -q "\"user\":\"$EXPECT_USER\"" <<<"$(curl -s -H "Authorization: Bearer $TOKEN" "$BASE/v1/whoami")" && ok "Bearer token authenticates (no LDAP)" || bad "bearer auth"
# token introspection (consumed by downstream services for auth coordination)
intro=$(curl -s -H "Authorization: Bearer $TOKEN" "$BASE/v1/auth/introspect")
{ grep -q '"active":true' <<<"$intro" && grep -q "\"user\":\"$EXPECT_USER\"" <<<"$intro"; } \
  && ok "GET /v1/auth/introspect -> active + identity" || bad "introspect" "$intro"
code=$(curl -s -o /dev/null -w '%{http_code}' -H 'Authorization: Bearer deadbeefbogus' "$BASE/v1/auth/introspect")
[ "$code" = "401" ] && ok "introspect bogus token -> 401" || bad "introspect bogus" "got $code"
code=$(curl -s -o /dev/null -w '%{http_code}' -H 'Authorization: Bearer deadbeefbogus' "$BASE/v1/whoami")
[ "$code" = "401" ] && ok "bogus bearer -> 401" || bad "bogus bearer" "got $code"
# Periodic refresh: re-mint a fresh JWT from live LDAP using the current token.
refr=$(curl -s -X POST -H "Authorization: Bearer $TOKEN" "$BASE/v1/auth/refresh")
NEWTOKEN=$(grep -oE '"token":"[^"]+"' <<<"$refr" | sed 's/.*"token":"//;s/"//')
{ [ -n "$NEWTOKEN" ] && grep -q "\"user\":\"$EXPECT_USER\"" <<<"$(curl -s -H "Authorization: Bearer $NEWTOKEN" "$BASE/v1/whoami")"; } \
  && ok "POST /v1/auth/refresh -> fresh usable JWT" || bad "refresh" "$refr"
# Stateless JWT: DELETE is a no-op (logout is client-side); the token stays valid
# until it expires (short TTL). Revocation is by expiry, not a server-side list.
code=$(curl -s -o /dev/null -w '%{http_code}' -X DELETE -H "Authorization: Bearer $TOKEN" "$BASE/v1/auth/token")
[ "$code" = "204" ] && ok "DELETE /v1/auth/token -> 204 (stateless no-op)" || bad "revoke" "got $code"
code=$(curl -s -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $TOKEN" "$BASE/v1/whoami")
[ "$code" = "200" ] && ok "stateless token still valid until expiry -> 200" || bad "stateless token" "got $code"

# ---- filesystem round-trip ----
echo "[filesystem]"
ROOT="00000000-0000-0000-0000-000000000000"      # all-zeros UUID = root
SUF="hb_$(date +%s)_$RANDOM"
A=(-u "$CRED")
uidof() { grep -oE '"uid":"[a-f0-9-]+"' | head -1 | sed 's/.*"uid":"//;s/"//'; }

out=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$ROOT" -d "{\"name\":\"$SUF\"}")
DIR=$(uidof <<<"$out"); [ -n "$DIR" ] && ok "POST /v1/dirs (create dir under root) -> uid" || bad "create dir" "$out"

out=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$DIR/files" -d '{"name":"hello.txt"}')
FILE=$(uidof <<<"$out"); [ -n "$FILE" ] && ok "POST /v1/dirs/{uid}/files (create file) -> uid" || bad "create file" "$out"

code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X PUT "$BASE/v1/files/$FILE/content" --data-binary 'hello rest world')
[ "$code" = "204" ] || [ "$code" = "200" ] && ok "PUT /v1/files/{uid}/content -> 2xx" || bad "put content" "got $code"

out=$(curl -s "${A[@]}" "$BASE/v1/files/$FILE/content")
[ "$out" = "hello rest world" ] && ok "GET content roundtrip matches" || bad "get content" "$out"

out=$(curl -s "${A[@]}" "$BASE/v1/nodes/$FILE")
grep -q '"name":"hello.txt"' <<<"$out" && ok "GET /v1/nodes/{uid} stat" || bad "stat" "$out"

out=$(curl -s "${A[@]}" "$BASE/v1/dirs/$DIR")
grep -q 'hello.txt' <<<"$out" && ok "GET /v1/dirs/{uid} lists file" || bad "list dir" "$out"

code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X DELETE "$BASE/v1/files/$FILE")
{ [ "$code" = "204" ] || [ "$code" = "200" ]; } && ok "DELETE /v1/files/{uid} -> 2xx" || bad "delete file" "got $code"

curl -s -o /dev/null "${A[@]}" -X DELETE "$BASE/v1/dirs/$DIR"   # cleanup

# ---- soft-delete a non-empty folder + leak-proof reachability ----
echo "[delete non-empty + reachability]"
# Build <root>/<suf>_del/sub/leaf.txt with content.
RD=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$ROOT" -d "{\"name\":\"${SUF}_del\"}" | uidof)
RSUB=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$RD" -d '{"name":"sub"}' | uidof)
LEAF=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$RSUB/files" -d '{"name":"leaf.txt"}' | uidof)
curl -s -o /dev/null "${A[@]}" -X PUT "$BASE/v1/files/$LEAF/content" --data-binary 'buried'

# Sanity: the buried file is reachable before the delete.
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" "$BASE/v1/files/$LEAF/content")
{ [ "$code" = "200" ]; } && ok "descendant readable before delete" || bad "pre-delete" "got $code"
# And a NON-admin member could also read it before the delete (read-by-default) —
# so any hiding after the delete is due to reachability, not a missing grant.
if [ -n "$USER2" ] && [ -n "$PASS2" ]; then
    U2=(-u "$USER2:$PASS2")
    code=$(curl -s -o /dev/null -w '%{http_code}' "${U2[@]}" "$BASE/v1/files/$LEAF/content")
    [ "$code" = "200" ] && ok "non-admin: descendant readable before delete (baseline)" \
        || bad "non-admin pre-delete baseline" "got $code (is FE_USER2 a member of the tenant?)"
fi

# A non-empty directory can now be soft-deleted directly (no recursive flag).
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X DELETE "$BASE/v1/dirs/$RD")
{ [ "$code" = "204" ] || [ "$code" = "200" ]; } && ok "DELETE non-empty dir -> 2xx (soft)" \
    || bad "delete non-empty" "got $code"

# The folder is gone from the root listing...
out=$(curl -s "${A[@]}" "$BASE/v1/dirs/$ROOT")
grep -q "${SUF}_del" <<<"$out" && bad "reachability" "deleted dir still listed at root" \
    || ok "deleted folder no longer listed at root"

# ...and for a NON-ADMIN its DESCENDANTS are hidden everywhere by reachability,
# even by direct UID (leak-proof — the child's own deleted flag is untouched, it's
# just unreachable).
#
# This MUST be checked as a non-admin: a tenant/system admin is deliberately EXEMPT
# from reachability hiding (AclManager admin bypass) so a superuser can inspect and
# recover a deleted subtree. FE_USER is an admin, so it would (correctly) still see
# the file — checking hiding as FE_USER would be meaningless.
if [ -n "$USER2" ] && [ -n "$PASS2" ]; then
    U2=(-u "$USER2:$PASS2")
    code=$(curl -s -o /dev/null -w '%{http_code}' "${U2[@]}" "$BASE/v1/files/$LEAF/content")
    [ "$code" != "200" ] && ok "non-admin: descendant file hidden by direct UID ($code)" \
        || bad "reachability LEAK" "buried file readable by a NON-admin under a deleted folder"
    code=$(curl -s -o /dev/null -w '%{http_code}' "${U2[@]}" "$BASE/v1/dirs/$RSUB")
    [ "$code" != "200" ] && ok "non-admin: descendant subdir not listable ($code)" \
        || bad "reachability LEAK" "subdir listable by a NON-admin under a deleted folder"
    code=$(curl -s -o /dev/null -w '%{http_code}' "${U2[@]}" "$BASE/v1/nodes/$LEAF")
    [ "$code" != "200" ] && ok "non-admin: descendant stat hidden by direct UID ($code)" \
        || bad "reachability LEAK" "stat readable by a NON-admin under a deleted folder"
else
    skip "reachability hiding for a NON-admin (set FE_USER2/FE_PASS2 to a non-admin member of the tenant)"
fi
# Admin exemption (intended, not a leak): the admin CAN still reach the deleted
# subtree by direct UID — a superuser is never locked out of recovering it.
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" "$BASE/v1/files/$LEAF/content")
[ "$code" = "200" ] && ok "admin exemption: admin still reaches deleted subtree (recovery)" \
    || bad "admin exemption" "admin unexpectedly blocked from a deleted subtree ($code)"

# ---- streaming (large file) + Range ----
echo "[streaming + range]"
SD=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$ROOT" -d "{\"name\":\"${SUF}_stream\"}" | uidof)
BF=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$SD/files" -d '{"name":"big.bin"}' | uidof)
# 2 MiB of deterministic data
head -c 2097152 /dev/zero | tr '\0' 'A' > /tmp/hb_big.bin
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X PUT "$BASE/v1/files/$BF/content" --data-binary @/tmp/hb_big.bin)
{ [ "$code" = "204" ] || [ "$code" = "200" ]; } && ok "PUT 2MiB (streaming upload) -> 2xx" || bad "stream upload" "got $code"
curl -s "${A[@]}" "$BASE/v1/files/$BF/content" -o /tmp/hb_big_dl.bin
[ "$(wc -c </tmp/hb_big_dl.bin)" = "2097152" ] && ok "GET 2MiB (streaming download) full size" || bad "stream download size" "$(wc -c </tmp/hb_big_dl.bin)"
cmp -s /tmp/hb_big.bin /tmp/hb_big_dl.bin && ok "streamed content matches" || bad "stream content mismatch"
# Range request: bytes 0-9 (10 bytes)
code=$(curl -s -o /tmp/hb_range -w '%{http_code}' "${A[@]}" -H 'Range: bytes=0-9' "$BASE/v1/files/$BF/content")
[ "$code" = "206" ] && ok "Range request -> 206" || bad "range status" "got $code"
[ "$(wc -c </tmp/hb_range)" = "10" ] && ok "Range returns requested 10 bytes" || bad "range size" "$(wc -c </tmp/hb_range)"
curl -s -o /dev/null "${A[@]}" -X DELETE "$BASE/v1/dirs/$SD"   # cleanup
rm -f /tmp/hb_big.bin /tmp/hb_big_dl.bin /tmp/hb_range

# ---- versioning + metadata + manipulation ----
echo "[versioning + metadata + manipulation]"
WS=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$ROOT" -d "{\"name\":\"${SUF}_ext\"}" | uidof)
F2=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$WS/files" -d '{"name":"v.txt"}' | uidof)
curl -s -o /dev/null "${A[@]}" -X PUT "$BASE/v1/files/$F2/content" --data-binary 'v1'
sleep 1; curl -s -o /dev/null "${A[@]}" -X PUT "$BASE/v1/files/$F2/content" --data-binary 'v2'
sleep 1; curl -s -o /dev/null "${A[@]}" -X PUT "$BASE/v1/files/$F2/content" --data-binary 'v3'

out=$(curl -s "${A[@]}" "$BASE/v1/files/$F2/versions")
vc=$(grep -oE '[0-9]{8}_[0-9]{6}' <<<"$out" | wc -l)
[ "$vc" -ge 3 ] && ok "GET /v1/files/{uid}/versions ($vc)" || bad "versions list" "$out"
TS=$(grep -oE '[0-9]{8}_[0-9]{6}(\.[0-9]+)?' <<<"$out" | head -1)
out=$(curl -s "${A[@]}" "$BASE/v1/files/$F2/versions/$TS")
[ -n "$out" ] && ok "GET specific version" || bad "get version" "$out"
out=$(curl -s "${A[@]}" -X POST "$BASE/v1/files/$F2/restore" -d "{\"version_timestamp\":\"$TS\"}")
grep -q 'restored_version' <<<"$out" && ok "POST restore version" || bad "restore" "$out"
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X POST "$BASE/v1/files/$F2/purge" -d '{"keep_count":1}')
[ "$code" = "204" ] && ok "POST purge -> 204" || bad "purge" "got $code"

curl -s -o /dev/null "${A[@]}" -X PUT "$BASE/v1/nodes/$F2/metadata/color" -d '{"value":"blue"}'
out=$(curl -s "${A[@]}" "$BASE/v1/nodes/$F2/metadata/color")
grep -q '"value":"blue"' <<<"$out" && ok "metadata PUT+GET key" || bad "metadata get" "$out"
out=$(curl -s "${A[@]}" "$BASE/v1/nodes/$F2/metadata")
grep -q '"color":"blue"' <<<"$out" && ok "metadata GET all" || bad "metadata getall" "$out"
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X DELETE "$BASE/v1/nodes/$F2/metadata/color")
[ "$code" = "204" ] && ok "metadata DELETE -> 204" || bad "metadata delete" "got $code"

code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X POST "$BASE/v1/nodes/$F2/rename" -d '{"new_name":"renamed_v.txt"}')
[ "$code" = "204" ] && ok "POST rename -> 204" || bad "rename" "got $code"
grep -q '"exists":true'  <<<"$(curl -s "${A[@]}" "$BASE/v1/nodes/$F2/exists")" && ok "exists true" || bad "exists true"
grep -q '"exists":false' <<<"$(curl -s "${A[@]}" "$BASE/v1/nodes/deadbeef-0000-0000-0000-000000000000/exists")" && ok "exists false (bogus uid)" || bad "exists false"
curl -s -o /dev/null "${A[@]}" -X DELETE "$BASE/v1/files/$F2"
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X POST "$BASE/v1/files/$F2/undelete")
[ "$code" = "204" ] && ok "soft-delete + POST undelete -> 204" || bad "undelete" "got $code"
SUB=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$WS" -d '{"name":"sub"}' | uidof)
CF=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$WS/files" -d '{"name":"copyme.txt"}' | uidof)
curl -s -o /dev/null "${A[@]}" -X PUT "$BASE/v1/files/$CF/content" --data-binary 'copy me'
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X POST "$BASE/v1/nodes/$CF/copy" -d "{\"destination_parent_uid\":\"$SUB\"}")
[ "$code" = "204" ] && ok "POST copy -> 204" || bad "copy" "got $code"
grep -q 'copyme.txt' <<<"$(curl -s "${A[@]}" "$BASE/v1/dirs/$SUB")" && ok "copied file appears in dest" || bad "copy result"

# error mapping
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" "$BASE/v1/nodes/deadbeef-0000-0000-0000-000000000000")
{ [ "$code" = "404" ] || [ "$code" = "500" ]; } && ok "stat bogus uid -> error status ($code)" || bad "stat bogus" "got $code"
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" "$BASE/v1/bogus/resource")
[ "$code" = "404" ] && ok "unknown route -> 404" || bad "unknown route" "got $code"

curl -s -o /dev/null "${A[@]}" -X DELETE "$BASE/v1/dirs/$WS"   # cleanup

# ---- admin + roles + ACL ----
echo "[admin + roles + ACL]"
grep -q 'total_space' <<<"$(curl -s "${A[@]}" "$BASE/v1/storage")" && ok "GET /v1/storage" || bad "storage"
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X POST "$BASE/v1/sync")
[ "$code" = "204" ] && ok "POST /v1/sync -> 204" || bad "sync" "got $code"

ROLE="hbrole_$(date +%s)"
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X POST "$BASE/v1/roles" -d "{\"role\":\"$ROLE\"}")
[ "$code" = "201" ] && ok "POST /v1/roles -> 201" || bad "create role" "got $code"
grep -q "$ROLE" <<<"$(curl -s "${A[@]}" "$BASE/v1/roles")" && ok "GET /v1/roles lists new role" || bad "list roles"
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X PUT "$BASE/v1/roles/$ROLE/users/carol")
[ "$code" = "204" ] && ok "PUT assign user to role -> 204" || bad "assign role" "got $code"
grep -q 'carol' <<<"$(curl -s "${A[@]}" "$BASE/v1/roles/$ROLE/users")" && ok "GET /v1/roles/{role}/users" || bad "role users"
grep -q "$ROLE" <<<"$(curl -s "${A[@]}" "$BASE/v1/users/carol/roles")" && ok "GET /v1/users/{user}/roles" || bad "user roles"
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X DELETE "$BASE/v1/roles/$ROLE/users/carol")
[ "$code" = "204" ] && ok "DELETE remove user from role -> 204" || bad "remove role member" "got $code"

GD=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$ROOT" -d "{\"name\":\"acl_$(date +%s)\"}" | uidof)
GF=$(curl -s "${A[@]}" -X POST "$BASE/v1/dirs/$GD/files" -d '{"name":"acl.txt"}' | uidof)
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X POST "$BASE/v1/nodes/$GF/permissions" -d '{"principal":"dave","permission":"r"}')
[ "$code" = "204" ] && ok "POST grant READ to dave -> 204" || bad "grant" "got $code"
grep -q '"has_permission":true' <<<"$(curl -s "${A[@]}" "$BASE/v1/nodes/$GF/permissions?user=dave&permission=r")" && ok "GET check: dave has READ" || bad "check perm true"
# role-based grant + role check
curl -s -o /dev/null "${A[@]}" -X POST "$BASE/v1/nodes/$GF/permissions" -d "{\"principal\":\"role:$ROLE\",\"permission\":\"r\"}"
grep -q '"has_permission":true' <<<"$(curl -s "${A[@]}" "$BASE/v1/nodes/$GF/permissions?user=carol&permission=r&roles=$ROLE")" && ok "GET check: carol(role) has READ" || bad "role check"
# self-check defaults to the CALLER's own identity (user + roles): the admin holds
# LIST_DELETED only via its system_admin role, so a no-user/no-roles check must use
# the caller's roles and pass (regression: checkPerm previously dropped them).
grep -q '"has_permission":true' <<<"$(curl -s "${A[@]}" "$BASE/v1/nodes/$GF/permissions?permission=l")" && ok "GET check defaults to caller roles (admin has LIST_DELETED)" || bad "self-role check"
# deny precedence
curl -s -o /dev/null "${A[@]}" -X POST "$BASE/v1/nodes/$GF/permissions" -d '{"principal":"erin","permission":"r"}'
curl -s -o /dev/null "${A[@]}" -X POST "$BASE/v1/nodes/$GF/permissions" -d '{"principal":"erin","permission":"r","effect":"deny"}'
grep -q '"has_permission":false' <<<"$(curl -s "${A[@]}" "$BASE/v1/nodes/$GF/permissions?user=erin&permission=r")" && ok "DENY overrides ALLOW" || bad "deny precedence"
# list ACL entries (backs the ACL editor); principals are bare, type 1 = role, effect 1 = DENY
acls=$(curl -s "${A[@]}" "$BASE/v1/nodes/$GF/acls")
{ grep -q '"principal":"dave"' <<<"$acls" && grep -q "\"principal\":\"$ROLE\"" <<<"$acls" && grep -q '"type":1' <<<"$acls"; } \
  && ok "GET /v1/nodes/{uid}/acls lists entries (user + role)" || bad "list acls" "$acls"
grep -q '"effect":1' <<<"$acls" && ok "acls include DENY effect" || bad "acls deny effect" "$acls"
code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X DELETE "$BASE/v1/nodes/$GF/permissions" -d '{"principal":"dave","permission":"r"}')
[ "$code" = "204" ] && ok "DELETE revoke permission -> 204" || bad "revoke" "got $code"

# ---- principals type-ahead (ACL editor) ----
echo "[principals type-ahead]"
# Seed a CLAIM-type ACL so the claim catalog has something to return.
CLAIM="dept=eng_$(date +%s)"
curl -s -o /dev/null "${A[@]}" -X POST "$BASE/v1/nodes/$GF/permissions" -d "{\"principal\":\"claim:$CLAIM\",\"permission\":\"r\"}"
out=$(curl -s "${A[@]}" "$BASE/v1/principals")
{ grep -q '"roles"' <<<"$out" && grep -q '"claims"' <<<"$out" && grep -q '"users"' <<<"$out"; } \
  && ok "GET /v1/principals returns roles+claims+users" || bad "principals shape" "$out"
grep -q "$CLAIM" <<<"$(curl -s "${A[@]}" "$BASE/v1/principals?types=claim")" \
  && ok "claim catalog includes granted claim" || bad "claim catalog"
grep -q "$CLAIM" <<<"$(curl -s "${A[@]}" "$BASE/v1/principals?types=claim&q=dept=")" \
  && ok "claim prefix filter matches" || bad "claim prefix match"
! grep -q "$CLAIM" <<<"$(curl -s "${A[@]}" "$BASE/v1/principals?types=claim&q=zzz_nomatch")" \
  && ok "claim prefix filter excludes non-matches" || bad "claim prefix exclude"
# Role type-ahead is sourced from LDAP groups (groupOfNames under the tenant),
# not the core role registry — so match a seeded tenant group by prefix.
grep -q '"administrators"' <<<"$(curl -s "${A[@]}" "$BASE/v1/principals?types=role&q=admin")" \
  && ok "role type-ahead by prefix (LDAP group)" || bad "role type-ahead"
grep -q '"roles":\[\]' <<<"$(curl -s "${A[@]}" "$BASE/v1/principals?types=claim")" \
  && ok "types=claim yields empty roles array" || bad "types filter"
code=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/v1/principals")
[ "$code" = "401" ] && ok "principals without creds -> 401" || bad "principals auth" "got $code"

code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X DELETE "$BASE/v1/roles/$ROLE")
[ "$code" = "204" ] && ok "DELETE /v1/roles/{role} -> 204" || bad "delete role" "got $code"
curl -s -o /dev/null "${A[@]}" -X DELETE "$BASE/v1/dirs/$GD"   # cleanup

# ---- hardening ----
echo "[hardening]"
# scoped CORS: the bridge echoes its configured HTTP_CORS_ORIGIN verbatim (never *).
# CORS_ORIGIN must equal that configured value (see the header for the default).
hdr=$(curl -s -D - -o /dev/null -X OPTIONS -H "Origin: $CORS_ORIGIN" "$BASE/v1/whoami")
grep -qi "access-control-allow-origin: $CORS_ORIGIN" <<<"$hdr" && ok "CORS scoped origin header" || bad "CORS header" "$(grep -i access-control <<<"$hdr" | head -1)"
! grep -qi 'access-control-allow-origin: \*' <<<"$hdr" && ok "CORS is not wildcard" || bad "CORS wildcard"
code=$(curl -s -o /dev/null -w '%{http_code}' -X OPTIONS "$BASE/v1/whoami")
[ "$code" = "204" ] && ok "OPTIONS preflight -> 204" || bad "preflight" "got $code"
# body-size cap (HTTP_MAX_BODY_BYTES). Exercising it means sending just over the
# cap, so only do it when the cap is small enough to be cheap (the size cap is
# enforced before routing, so an over-cap body is rejected with 413 regardless of
# the target). The dev default is 100 MiB → SKIP unless the bridge is run with a
# small HTTP_MAX_BODY_BYTES and FE_MAX_BODY is set to match.
if [ "$MAX_BODY" -le 16777216 ]; then
    over=$((MAX_BODY + 4096))
    head -c "$over" /dev/zero > /tmp/hb_toobig
    code=$(curl -s -o /dev/null -w '%{http_code}' "${A[@]}" -X PUT "$BASE/v1/files/$ROOT/content" --data-binary @/tmp/hb_toobig)
    [ "$code" = "413" ] && ok "oversized body (> ${MAX_BODY}B) -> 413" || bad "body cap" "got $code (cap=$MAX_BODY)"
    rm -f /tmp/hb_toobig
else
    skip "body-size cap (cap=${MAX_BODY}B too large to exercise cheaply; run the bridge with a small HTTP_MAX_BODY_BYTES and set FE_MAX_BODY)"
fi

echo "=========================================================="
echo " RESULTS:  PASS=$PASS  FAIL=$FAIL  SKIP=$SKIP"
[ "$FAIL" -gt 0 ] && { echo " Failed:"; printf '   - %s\n' "${FAILED[@]}"; }
echo "=========================================================="
[ "$FAIL" -eq 0 ]
